﻿You can find more information about this software at http://attesoro.org/
It was created by Stephen Ostermiller (ostermiller.org)

Please show your support.

Luis Majano