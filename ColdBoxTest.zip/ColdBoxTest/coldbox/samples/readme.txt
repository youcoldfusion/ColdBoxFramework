Welcome to the ColdBox Samples Gallery.

This is small app, of course powered by ColdBox, that displays some of the sample
applications I have created and some of them are re-writes of FAMOUS open source projects
that I credit below.  

If you have ported an app to ColdBox or have an application you would like to share 
with the ColdBox community.  Please email me at info@coldboxframework.com with your application
so I can include it in the downloads section and the main release.
*******************************************************
Installation
*******************************************************
In order to make the samples gallery functional you will need to do the following:

1) Copy the coldbox extracted archive to your web root
You should have the following directory structure in the web root:

+ {Web_Root}
|---+ coldbox
    |---+ ApplicationTemplate
    |---+ install
    |---+ samples
    |---+ system

3) Browse to the samples directory on your browser and that is it.
http://{your web address}/coldbox/samples

**IMPORTANT: Some sample applications need installation of server side components or
             databases. Please look at each of the installation instructions on each
             application.
