ColdBox 3.5 Validation Sample
--------------------------------------------------------------------------------------------------------------------

	This is a sample application that shows off the validation built in to ColdBox.
	This application was forked from the Hyrule project by Dan Vega.  All inspiration is because
	of his awesome work.

Requirements
--------------------------------------------------------------------------------------------------------------------

	ColdBox 3.5
	ColdFusion 9.01
	Create a datasource and database called 'validationSample'

