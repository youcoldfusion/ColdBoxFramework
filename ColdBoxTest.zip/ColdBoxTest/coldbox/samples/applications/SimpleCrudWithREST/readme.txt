This is a simple CRUD application that leverages ColdBox and a Service layer.

To install:

- Create database called contacts and construct it with the provided MySQL.sql
- Create the datasource called "contacts" in the CF Admin
- Run the app.

This app does not have an edit feature as we recommend the users add it to the application
in order to learn!!

Good luck!

Luis Majano